#if !defined(VT100_H_)
#define VT100_H_

#include <stdint.h>

void vt100_handle_input(uint8_t c);

#endif // VT100