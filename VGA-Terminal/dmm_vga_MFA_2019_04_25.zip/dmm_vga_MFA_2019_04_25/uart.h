#if !defined(UART_H_)
#define UART_H_

#define UART0_BUFLEN 16
extern volatile uint8_t uart0_buf[UART0_BUFLEN];
extern volatile uint8_t uart0_index;

void uart_putchar(uint8_t c);

#endif // UART_H_