#include <avr/io.h>
#include <stdint.h>
#include "global.h"
#include "uart.h"

volatile uint8_t uart0_buf[UART0_BUFLEN];
volatile uint8_t uart0_index;

void uart_putchar(uint8_t c)
{
	while(!(UCSR0A & (1<<UDRE0)));

	UDR0 = c;
}
