/*
 PC AT Keyboard Interface for AVR
 based on atmel aplication Note: AVR313 (http://www.atmel.com/dyn/resources/prod_documents/DOC1235.PDF)
 
 by Maximilian Laiacker mlaiacker@gmx.de
 http://der-max.no-ip.org
 
Tastatur-Datenleitung muss an PD2 (RXD1).
Tastatur-Taktleitung muss an PD4 (XCK1).
 *****************************************
 
 function key scancodes, 
 a function key always leads a 0 character
 
 to handle like this:
 
 u08 c;
 c=kbReadKey();
 switch (c){
   case 0:  // next character in buffer is a function key scancode
     switch ( kbReadKey() ){ // read function key
       case K_UP: 
         SetMotorL(100);
         SetMotorR(100);
         break;
       case K_LEFT:
         SetMotorL(0);
         SetMotorR(100);
         break;
       case K_DOWN: 
         SetMotorL(-100);
         SetMotorR(-100);
         break;
       case K_RIGHT:
         SetMotorR(0);
         SetMotorL(100);
         break;
     }
           
   default: string+=c // add character to string or something else    
 }
 
 
*/

#define K_F1 0x05
#define K_F2 0x06
#define K_F3 0x04 
#define K_F4 0x0C 
#define K_F5 0x03 
#define K_F6 0x0B 
#define K_F7 0x83 
#define K_F8 0x0A 
#define K_F9 0x01 
#define K_F10 0x09 
#define K_F11 0x78 
#define K_F12 0x07

#define K_ESC 0x76
#define K_ALT 0x11
#define K_STRG 0x14
#define K_WINL 0x27	// left windows key
#define K_WINR 0x1F
#define K_WINR2 0x2F	// second right windows key
#define K_ALTGR 0x11

#define K_DRUCK    0x7C 
#define K_ROLLEN   0x7E
#define K_EINF     0x70
#define K_POS1     0x6C
#define K_PAGEUP   0x7D
#define K_PAGEDOWN 0x7A
#define K_END 	   0x69
#define K_ENTF 	   0x71

#define K_UP    0x75
#define K_DOWN  0x72
#define K_LEFT  0x6B
#define K_RIGHT 0x74

#define K_NUM 0x77 //? Num

//Numpad FuncKey
#define K_DIV 0x4A    // '/'
#define K_ENTER 0x5a 

#define sbi(value,bit)   	( value |= 1<<bit )
#define cbi(value,bit) 	( value &= ~(1<<bit) )
#define bitset(value,bit)   	( value & (1<<(bit)) )

void  kbInit(void);		// external interupt Enable and stuff
unsigned char  kbKeyPressed(void);	// returns 1 if a key is pressed
unsigned char  kbReadKey(void);		// returns ASCII code of pressed key, waits until a key is pressed
unsigned char  kbKey(unsigned char x);	// returns 1 if Key x is pressed (scancode)
void  kbInt(void); 		// interrupt handler
uint8_t decode(unsigned char sc);
uint8_t kb_readkey(void);

#define KB_BUFF_SIZE 16
extern volatile uint8_t kb_buffer[KB_BUFF_SIZE];
extern volatile uint8_t kb_bufpos;
